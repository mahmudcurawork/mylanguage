<option selected>No of times reads</option>

<?php if(count($options) > 0): ?>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($option->no_of_read); ?>"><?php echo e($option->no_of_read); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>No Options Found</p>
<?php endif; ?>

<?php /**PATH /Applications/MAMP/htdocs/mylanguage/resources/views/selectForm.blade.php ENDPATH**/ ?>