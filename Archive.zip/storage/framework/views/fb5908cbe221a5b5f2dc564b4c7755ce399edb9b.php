<?php if($words->count() > 0): ?>
    <?php
        $counter = 0;
    ?>
    <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="wordRow_<?php echo e($word->id); ?>">
            <th scope="row">
                <input type="checkbox" name="select" id="select1">
                <label for="select1"><?php echo e(++$counter); ?>. <?php echo e($word->word); ?></label>

            </th>
            <td>
                <span class="d-none" id="<?php echo e($word->id); ?>_definition"><?php echo e($word->definition); ?></span>

                <img data-toggle="tooltip" data-placement="top" title="View definition"
                    onclick="toggleDefinition('<?php echo e($word->id); ?>_definition')" src="/images/eye-black.svg" alt="view icon">

            </td>
            <td>

                <?php if ($word->learned) { ?>
                <button class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="Click to mark not learned">
                    <img src="/images/check2-circle.svg" alt="Learned">
                </button>
                
                <?php }else { ?>
                <button class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="Click to mark learned" onclick="markLearned(<?php echo e($word->id); ?>, <?php echo e($word->no_of_read); ?>)">
                    <img src="/images/dash-circle.svg" alt="Not learned">
                </button>
                
                <?php } ?>
                <small><?php echo e($word->no_of_read? '(' . $word->no_of_read . ')':''); ?></small>

            </td>
            <td>
                <button class="btn btn-secondary" 
                onclick="editData(<?php echo e($word->id); ?>,'<?php echo e($word->word); ?>','<?php echo e($word->definition); ?>')"
                data-toggle="tooltip" data-placement="top" title="edit">
                    <img src="/images/pencil.svg" alt="edit icon">
                </button>
                <button class="btn btn-secondary" onclick="deleteData(<?php echo e($word->id); ?>)" data-toggle="tooltip" data-placement="top" title="delete">
                    <img src="/images/trash.svg" alt="delete icon">
                </button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    No words found
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/mylanguage/resources/views/wordsTable.blade.php ENDPATH**/ ?>