<?php if($articles->count() > 0): ?>

    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="articleRow_<?php echo e($article->id); ?>">
            <th scope="row">
                <span 
                style="cursor: pointer;"
                onclick="loadWordsOnArticle(<?php echo e($article->id); ?>)"
                data-toggle="tooltip" data-placement="top" title="Unlearned">
                    <?php echo e($article->title.' ('.$article->unlearned. ')'); ?>

                </span>

            </th>
            <td colspan="2">
                <?php echo e($article->reference); ?>

                
            </td>
            
            <td>
                <button class="btn btn-secondary" 
                onclick="editArticle(<?php echo e($article->id); ?>,'<?php echo e($article->title); ?>','<?php echo e($article->reference); ?>')"
                data-toggle="tooltip" data-placement="top" title="edit">
                    <img src="/images/pencil.svg" alt="edit icon">
                </button>
                <button class="btn btn-secondary" onclick="deleteArticle(<?php echo e($article->id); ?>)" data-toggle="tooltip" data-placement="top" title="delete">
                    <img src="/images/trash.svg" alt="delete icon">
                </button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    No articles found
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/mylanguage/resources/views/articlesTable.blade.php ENDPATH**/ ?>