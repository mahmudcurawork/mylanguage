<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="wordModalLabel">Modal title</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="input-group">
                <input type="text" id="word" class="form-control modalForm mb-3" placeholder="word">
                <span style="cursor: pointer" onclick="clearField('word')"><img src="/images/x-lg.svg"
                        alt="clear"></span>
            </div>
            <div class="input-group">
                <input type="text" id="definition" class="form-control modalForm mb-3" placeholder="definition">
                <span style="cursor: pointer" onclick="clearField('definition')"><img src="/images/x-lg.svg"
                        alt="clear"></span>
            </div>
            <div class="input-group">
                <select id="articles" name="articles"

                class="form-select" aria-label="">

                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="hideModal('wordModal')">
                <img src="/images/x-lg-white.svg" alt="close icon">
            </button>

            <button type="submit" id="saveData" class="btn btn-secondary" onclick="">
                <img src="/images/save.svg" alt="save icon">
            </button>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/mylanguage/resources/views/addModal.blade.php ENDPATH**/ ?>