<option value="0">Articles</option>

<?php if(count($articles) > 0): ?>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($article->id); ?>"
            <?php echo e($article->id == $articleId?'selected':''); ?>

            ><?php echo e($article->title); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>No Options Found</p>
<?php endif; ?>

<?php /**PATH /Applications/MAMP/htdocs/mylanguage/resources/views/selectFormArticle.blade.php ENDPATH**/ ?>