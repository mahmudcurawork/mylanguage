<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body">
            Are you sure to delete this word?
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-danger" id="actionYes" onclick="">Delete</button>

            <button type="button" class="btn btn-secondary" id="actionNo" onclick="cancelAction()">Cancel</button>
        </div>
    </div>
</div>
